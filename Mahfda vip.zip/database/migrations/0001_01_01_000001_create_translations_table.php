<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('translations', function (Blueprint $table) {
            $table->id();
            $table->string('game_name');
            $table->string('translation_name');
            $table->string('translator');
            $table->enum('type', ['free', 'popular', 'exclusive']);
            $table->string('version');
            $table->text('description')->nullable();
            $table->text('installation_instructions')->nullable();
            $table->string('image')->nullable();
            $table->string('mediafire_url')->nullable();
            $table->string('file_path')->nullable();
            $table->integer('downloads')->default(0);
            $table->boolean('is_published')->default(true);
            $table->string('category')->nullable();
            $table->integer('completion_percentage')->default(100);
            $table->timestamp('release_date')->nullable();
            $table->timestamp('last_updated')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('translations');
    }
};