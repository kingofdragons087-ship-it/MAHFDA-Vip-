<div class="bg-gray-800 rounded-xl overflow-hidden hover:bg-gray-700 transition duration-300">
    <div class="relative">
        @if($translation->image)
            <img src="{{ asset('storage/' . $translation->image) }}" 
                 alt="{{ $translation->game_name }}" 
                 class="w-full h-48 object-cover">
        @else
            <div class="w-full h-48 bg-gray-700 flex items-center justify-center">
                <span class="text-gray-500">لا توجد صورة</span>
            </div>
        @endif
        
        <div class="absolute top-2 right-2">
            <span class="{{ $translation->badge_class }} text-white px-3 py-1 rounded-full text-sm font-bold">
                {{ $translation->type_label }}
            </span>
        </div>
    </div>
    
    <div class="p-4">
        <h3 class="text-lg font-bold">{{ $translation->game_name }}</h3>
        <p class="text-sm text-gray-400">تعريب: {{ $translation->translation_name }}</p>
        <p class="text-xs text-gray-500">المترجم: {{ $translation->translator }}</p>
        
        <div class="flex items-center justify-between mt-3">
            <span class="text-xs text-gray-400">الإصدار {{ $translation->version }}</span>
            <span class="text-xs text-gray-400">📥 {{ $translation->formatted_downloads }}</span>
        </div>
        
        <div class="mt-3">
            <a href="{{ route('translations.show', $translation->id) }}" 
               class="block text-center bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg text-sm">
                عرض التفاصيل
            </a>
        </div>
    </div>
</div>