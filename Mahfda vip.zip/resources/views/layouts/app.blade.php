<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'MAHFDA VIP - منصة تعريبات الألعاب العربية')</title>
    
    <!-- ربط ملفات التصميم (Vite) -->
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="bg-gray-900 text-gray-100 font-sans antialiased">
    
    <!-- شريط التنقل -->
    <nav class="bg-gray-800 border-b border-gray-700">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16 items-center">
                <div class="flex items-center">
                    <a href="{{ route('home') }}" class="text-xl font-bold bg-gradient-to-r from-purple-500 to-blue-500 bg-clip-text text-transparent">
                        MAHFDA VIP
                    </a>
                </div>

                <div class="flex items-center gap-4">
                    @auth
                        @if(auth()->user()->isAdmin())
                            <a href="{{ route('admin.dashboard') }}" class="text-sm text-gray-300 hover:text-white">
                                لوحة التحكم
                            </a>
                        @endif
                        
                        <div class="relative">
                            <img src="{{ auth()->user()->avatar }}" alt="{{ auth()->user()->name }}" 
                                 class="w-8 h-8 rounded-full cursor-pointer">
                        </div>
                        
                        <form method="POST" action="{{ route('logout') }}" class="inline">
                            @csrf
                            <button type="submit" class="text-sm text-gray-300 hover:text-white">
                                خروج
                            </button>
                        </form>
                    @else
                        <a href="{{ route('auth.google') }}" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm">
                            دخول بـ Google
                        </a>
                    @endauth
                </div>
            </div>
        </div>
    </nav>

    <!-- المحتوى الرئيسي -->
    <main class="min-h-screen">
        @yield('content')
    </main>

    <!-- التذييل -->
    <footer class="bg-gray-800 border-t border-gray-700 mt-12">
        <div class="max-w-7xl mx-auto px-4 py-8 text-center text-gray-400">
            <p>{{ date('Y') }} MAHFDA VIP - جميع الحقوق محفوظة لفريق MAHFDA AR</p>
        </div>
    </footer>

</body>
</html>