@extends('layouts.app')

@section('title', $translation->game_name . ' - MAHFDA VIP')

@section('content')
<div class="max-w-4xl mx-auto px-4 py-12">
    <div class="bg-gray-800 rounded-xl overflow-hidden shadow-lg border border-gray-700">
        <!-- صورة اللعبة -->
        @if($translation->image)
            <img src="{{ asset('storage/' . $translation->image) }}" 
                 alt="{{ $translation->game_name }}" 
                 class="w-full h-64 object-cover">
        @else
            <div class="w-full h-64 bg-gray-700 flex items-center justify-center">
                <span class="text-gray-500 text-xl">لا توجد صورة</span>
            </div>
        @endif
        
        <div class="p-8">
            <div class="flex items-center justify-between mb-4 flex-wrap gap-2">
                <h1 class="text-3xl font-bold text-white">{{ $translation->game_name }}</h1>
                <span class="{{ $translation->badge_class }} text-white px-4 py-2 rounded-full text-sm font-bold">
                    {{ $translation->type_label }}
                </span>
            </div>
            
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6 bg-gray-700 p-4 rounded-lg">
                <div>
                    <p class="text-gray-400 text-sm">اسم التعريب</p>
                    <p class="font-semibold text-white">{{ $translation->translation_name }}</p>
                </div>
                <div>
                    <p class="text-gray-400 text-sm">المترجم</p>
                    <p class="font-semibold text-white">{{ $translation->translator }}</p>
                </div>
                <div>
                    <p class="text-gray-400 text-sm">الإصدار</p>
                    <p class="font-semibold text-white">{{ $translation->version }}</p>
                </div>
                <div>
                    <p class="text-gray-400 text-sm">الحالة</p>
                    <p class="font-semibold text-white">{{ $translation->completion_percentage }}% مكتمل</p>
                </div>
            </div>
            
            <div class="mb-6">
                <h3 class="text-lg font-bold text-white mb-2">الوصف</h3>
                <p class="text-gray-300 leading-relaxed">{{ $translation->description }}</p>
            </div>
            
            <div class="mb-6">
                <h3 class="text-lg font-bold text-white mb-2">تعليمات التثبيت</h3>
                <div class="bg-gray-900 p-4 rounded-lg text-gray-300 border border-gray-700">
                    {{ $translation->installation_instructions }}
                </div>
            </div>
            
            <div class="flex items-center justify-between text-sm text-gray-400 mb-6 border-t border-gray-700 pt-4">
                <span>آخر تحديث: {{ $translation->last_updated->format('d F Y') }}</span>
                <span>📥 {{ $translation->formatted_downloads }} تحميل</span>
            </div>
            
            <!-- زر التحميل -->
            <div class="mt-6">
                @php
                    $canDownload = auth()->check() ? auth()->user()->canDownload($translation) : ($translation->type === 'free');
                @endphp
                
                @if($canDownload)
                    <a href="{{ route('translations.download', $translation->id) }}" 
                       class="block w-full text-center bg-green-600 hover:bg-green-700 text-white py-4 rounded-lg text-xl font-bold transition shadow-lg">
                        📥 تحميل التعريب
                    </a>
                @elseif($translation->type === 'free')
                    <a href="{{ route('translations.download', $translation->id) }}" 
                       class="block w-full text-center bg-green-600 hover:bg-green-700 text-white py-4 rounded-lg text-xl font-bold transition shadow-lg">
                        📥 تحميل التعريب
                    </a>
                @else
                    <div class="bg-gray-700 p-6 rounded-lg text-center border border-gray-600">
                        <p class="text-2xl mb-4 text-white">🔒 هذا التعريب متاح للمشتركين فقط</p>
                        
                        @if($translation->type === 'popular')
                            <p class="text-lg mb-4 text-gray-300">اشترك في خطة Popular VIP للحصول على هذا التعريب</p>
                            <p class="text-3xl font-bold mb-4 text-blue-400">$3 / شهر</p>
                        @else
                            <p class="text-lg mb-4 text-gray-300">اشترك في خطة Premium VIP للحصول على هذا التعريب</p>
                            <p class="text-3xl font-bold mb-4 text-purple-400">$5 / شهر</p>
                        @endif
                        
                        @guest
                            <a href="{{ route('auth.google') }}" class="inline-block bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg transition">
                                تسجيل دخول بـ Google
                            </a>
                        @else
                            <a href="{{ route('subscribe', ['plan' => $translation->type === 'popular' ? 'popular' : 'premium']) }}" 
                               class="inline-block bg-purple-600 hover:bg-purple-700 text-white px-8 py-3 rounded-lg transition">
                                اشترك الآن
                            </a>
                        @endguest
                    </div>
                @endif
            </div>
        </div>
    </div>
</div>
@endsection