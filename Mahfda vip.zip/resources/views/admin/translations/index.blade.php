@extends('layouts.app')

@section('title', 'إدارة التعريبات - MAHFDA VIP')

@section('content')
<div class="max-w-7xl mx-auto px-4 py-12">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-3xl font-bold text-white">إدارة التعريبات</h1>
        <a href="{{ route('admin.translations.create') }}" class="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg transition">
            + إضافة تعريب
        </a>
    </div>

    <div class="bg-gray-800 rounded-xl overflow-hidden border border-gray-700">
        <table class="w-full text-right">
            <thead class="bg-gray-700 text-gray-300">
                <tr>
                    <th class="p-4">اللعبة</th>
                    <th class="p-4">النوع</th>
                    <th class="p-4">الإصدار</th>
                    <th class="p-4">التحميلات</th>
                    <th class="p-4">الحالة</th>
                    <th class="p-4">الإجراءات</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-700">
                @foreach($translations as $trans)
                <tr class="hover:bg-gray-700 transition">
                    <td class="p-4 text-white">{{ $trans->game_name }}</td>
                    <td class="p-4"><span class="{{ $trans->badge_class }} text-white px-2 py-1 rounded text-xs">{{ $trans->type_label }}</span></td>
                    <td class="p-4 text-gray-300">{{ $trans->version }}</td>
                    <td class="p-4 text-gray-300">{{ $trans->formatted_downloads }}</td>
                    <td class="p-4">
                        @if($trans->is_published)
                            <span class="text-green-400 text-xs">منشور</span>
                        @else
                            <span class="text-red-400 text-xs">مسودة</span>
                        @endif
                    </td>
                    <td class="p-4 flex gap-2">
                        <a href="{{ route('admin.translations.edit', $trans->id) }}" class="text-blue-400 hover:text-blue-300 text-sm">تعديل</a>
                        <form action="{{ route('admin.translations.destroy', $trans->id) }}" method="POST" onsubmit="return confirm('هل أنت متأكد؟')">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="text-red-400 hover:text-red-300 text-sm">حذف</button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
        <div class="p-4">
            {{ $translations->links() }}
        </div>
    </div>
</div>
@endsection