@extends('layouts.app')

@section('title', 'لوحة التحكم - MAHFDA VIP')

@section('content')
<div class="max-w-7xl mx-auto px-4 py-12">
    <h1 class="text-3xl font-bold mb-8 text-white">لوحة التحكم</h1>
    
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        <div class="bg-gray-800 p-6 rounded-xl border border-gray-700">
            <h3 class="text-gray-400 text-sm">إجمالي المستخدمين</h3>
            <p class="text-3xl font-bold text-white">{{ $totalUsers }}</p>
        </div>
        <div class="bg-gray-800 p-6 rounded-xl border border-gray-700">
            <h3 class="text-gray-400 text-sm">إجمالي التعريبات</h3>
            <p class="text-3xl font-bold text-white">{{ $totalTranslations }}</p>
        </div>
        <div class="bg-gray-800 p-6 rounded-xl border border-gray-700">
            <h3 class="text-gray-400 text-sm">المشتركين النشطين</h3>
            <p class="text-3xl font-bold text-green-400">{{ $activeSubscriptions }}</p>
        </div>
        <div class="bg-gray-800 p-6 rounded-xl border border-gray-700">
            <h3 class="text-gray-400 text-sm">إجمالي التحميلات</h3>
            <p class="text-3xl font-bold text-blue-400">{{ $totalDownloads }}</p>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <!-- قسم إدارة التعريبات -->
        <div class="bg-gray-800 p-6 rounded-xl border border-gray-700">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-bold text-white">آخر التعريبات</h2>
                <a href="{{ route('admin.translations.create') }}" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm transition">
                    + إضافة جديد
                </a>
            </div>
            <ul class="space-y-3">
                @foreach($latestTranslations as $trans)
                    <li class="flex justify-between items-center border-b border-gray-700 pb-2">
                        <span class="text-gray-300">{{ $trans->game_name }}</span>
                        <span class="text-xs text-gray-500">{{ $trans->created_at->diffForHumans() }}</span>
                    </li>
                @endforeach
            </ul>
            <div class="mt-4 text-center">
                <a href="{{ route('admin.translations.index') }}" class="text-blue-400 hover:text-blue-300 text-sm">عرض كل التعريبات →</a>
            </div>
        </div>

        <!-- قسم إدارة المستخدمين -->
        <div class="bg-gray-800 p-6 rounded-xl border border-gray-700">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-bold text-white">آخر المستخدمين</h2>
            </div>
            <ul class="space-y-3">
                @foreach($latestUsers as $user)
                    <li class="flex justify-between items-center border-b border-gray-700 pb-2">
                        <div class="flex items-center gap-2">
                            <img src="{{ $user->avatar }}" class="w-6 h-6 rounded-full">
                            <span class="text-gray-300">{{ $user->name }}</span>
                        </div>
                        <span class="text-xs text-gray-500">{{ $user->created_at->diffForHumans() }}</span>
                    </li>
                @endforeach
            </ul>
            <div class="mt-4 text-center">
                <a href="{{ route('admin.users.index') }}" class="text-blue-400 hover:text-blue-300 text-sm">عرض كل المستخدمين →</a>
            </div>
        </div>
    </div>
</div>
@endsection