@extends('layouts.app')

@section('title', 'MAHFDA VIP - منصة تعريبات الألعاب العربية')

@section('content')
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
    
    <div class="text-center mb-16">
        <h1 class="text-4xl md:text-5xl font-bold mb-4 text-white">MAHFDA VIP - منصة تعريبات الألعاب العربية</h1>
        <p class="text-xl text-gray-400 max-w-2xl mx-auto">اكتشف أفضل التعريبات العربية للألعاب، بأيدي فريق MAHFDA AR</p>
    </div>

    <!-- الأقسام الثلاثة -->
    <div class="space-y-20">
        
        <!-- قسم المجانية -->
        <section>
            <h2 class="text-2xl font-bold mb-6 text-white">🆓 التعريبات المجانية</h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                @foreach($freeTranslations as $translation)
                    @include('partials.translation-card', ['translation' => $translation])
                @endforeach
            </div>
        </section>

        <!-- قسم الشائعة -->
        <section>
            <h2 class="text-2xl font-bold mb-6 text-white">⭐ التعريبات الشائعة VIP</h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                @foreach($popularTranslations as $translation)
                    @include('partials.translation-card', ['translation' => $translation])
                @endforeach
            </div>
        </section>

        <!-- قسم الحصرية -->
        <section>
            <h2 class="text-2xl font-bold mb-6 text-white">👑 التعريبات الحصرية VIP</h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                @foreach($exclusiveTranslations as $translation)
                    @include('partials.translation-card', ['translation' => $translation])
                @endforeach
            </div>
        </section>
    </div>

    <!-- خطط الاشتراك -->
    <div class="mt-20 bg-gray-800 rounded-2xl p-8 text-center border border-gray-700">
        <h2 class="text-3xl font-bold mb-8 text-white">خطط الاشتراك في MAHFDA VIP</h2>
        <div class="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div class="bg-gray-700 rounded-xl p-6 border border-gray-600">
                <h3 class="text-2xl font-bold text-blue-400">⭐ Popular VIP</h3>
                <p class="text-4xl font-bold mt-4 text-white">$3</p>
                <p class="text-gray-400 mb-4">شهرياً</p>
                <ul class="text-right text-gray-300 space-y-1 mb-6 px-4">
                    <li>✅ جميع التعريبات المجانية</li>
                    <li>✅ التعريبات الشائعة VIP</li>
                    <li>❌ التعريبات الحصرية VIP</li>
                </ul>
                <a href="{{ route('subscribe', ['plan' => 'popular']) }}" class="block bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg transition">اشترك الآن</a>
            </div>
            <div class="bg-gray-700 rounded-xl p-6 border-2 border-purple-500">
                <h3 class="text-2xl font-bold text-purple-400">👑 Premium VIP</h3>
                <p class="text-4xl font-bold mt-4 text-white">$5</p>
                <p class="text-gray-400 mb-4">شهرياً</p>
                <ul class="text-right text-gray-300 space-y-1 mb-6 px-4">
                    <li>✅ جميع التعريبات المجانية</li>
                    <li>✅ التعريبات الشائعة VIP</li>
                    <li>✅ التعريبات الحصرية VIP</li>
                </ul>
                <a href="{{ route('subscribe', ['plan' => 'premium']) }}" class="block bg-purple-600 hover:bg-purple-700 text-white py-3 rounded-lg transition">اشترك الآن</a>
            </div>
        </div>
    </div>
</div>
@endsection