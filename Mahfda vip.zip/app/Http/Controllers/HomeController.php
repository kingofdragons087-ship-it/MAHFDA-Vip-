<?php

namespace App\Http\Controllers;

use App\Models\Translation;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        $freeTranslations = Translation::where('type', 'free')->where('is_published', true)->latest()->take(6)->get();
        $popularTranslations = Translation::where('type', 'popular')->where('is_published', true)->latest()->take(6)->get();
        $exclusiveTranslations = Translation::where('type', 'exclusive')->where('is_published', true)->latest()->take(6)->get();

        return view('home.index', compact('freeTranslations', 'popularTranslations', 'exclusiveTranslations'));
    }
}