<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\PayPalWebhookService;

class PayPalWebhookController extends Controller
{
    protected $webhookService;

    public function __construct(PayPalWebhookService $webhookService)
    {
        $this->webhookService = $webhookService;
    }

    public function handle(Request $request)
    {
        // التحقق من التوقيع (يمكن إضافته لاحقاً للأمان)
        $this->webhookService->handleWebhook($request);
        return response()->json(['status' => 'success']);
    }
}