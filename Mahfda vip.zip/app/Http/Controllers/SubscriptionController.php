<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\SubscriptionService;

class SubscriptionController extends Controller
{
    protected $subscriptionService;

    public function __construct(SubscriptionService $subscriptionService)
    {
        $this->subscriptionService = $subscriptionService;
    }

    public function subscribe($plan)
    {
        $user = auth()->user();
        if (!$user) {
            return redirect()->route('auth.google');
        }

        // تحديد ID الخطة حسب البيئة
        $planId = $plan === 'popular' ? env('PAYPAL_POPULAR_PLAN_ID') : env('PAYPAL_PREMIUM_PLAN_ID');
        $price = $plan === 'popular' ? 3 : 5;

        return view('subscriptions.checkout', compact('plan', 'planId', 'price', 'user'));
    }

    public function success(Request $request)
    {
        // سيتم تفعيل الاشتراك عبر Webhook، لكن نرسل المستخدم للصفحة الرئيسية مع رسالة نجاح
        return redirect()->route('home')->with('success', 'تم الاشتراك بنجاح!');
    }

    public function cancel()
    {
        return redirect()->route('home')->with('error', 'تم إلغاء عملية الاشتراك');
    }
}