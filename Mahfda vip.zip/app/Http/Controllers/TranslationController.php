<?php

namespace App\Http\Controllers;

use App\Models\Translation;
use App\Models\Download;
use App\Services\StorageService;
use Illuminate\Http\Request;

class TranslationController extends Controller
{
    protected $storageService;

    public function __construct(StorageService $storageService)
    {
        $this->storageService = $storageService;
    }

    public function show($id)
    {
        $translation = Translation::where('id', $id)->where('is_published', true)->firstOrFail();
        return view('translations.show', compact('translation'));
    }

    public function download($id)
    {
        $translation = Translation::findOrFail($id);
        $user = auth()->user();

        // التحقق من الصلاحية
        if ($translation->type !== 'free' && (!$user || !$user->canDownload($translation))) {
            abort(403, 'ليس لديك صلاحية لتحميل هذا التعريب');
        }

        // تسجيل التحميل
        if ($user) {
            Download::create([
                'user_id' => $user->id,
                'translation_id' => $translation->id,
                'ip_address' => request()->ip(),
                'downloaded_at' => now(),
            ]);
        }

        $translation->increment('downloads');

        // تحميل الملف
        if ($translation->type === 'free') {
            return redirect()->away($translation->mediafire_url);
        } else {
            $filePath = $translation->file_path;
            if ($filePath && $this->storageService->getPrivateFile($filePath)) {
                return response()->download(storage_path("app/{$filePath}"), $translation->game_name . '.zip');
            }
        }

        abort(404, 'الملف غير موجود');
    }
}