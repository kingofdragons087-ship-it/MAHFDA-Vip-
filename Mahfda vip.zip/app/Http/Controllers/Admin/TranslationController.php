<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Translation;
use App\Services\StorageService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class TranslationController extends Controller
{
    protected $storageService;

    public function __construct(StorageService $storageService)
    {
        $this->storageService = $storageService;
    }

    public function index()
    {
        $translations = Translation::latest()->paginate(20);
        return view('admin.translations.index', compact('translations'));
    }

    public function create()
    {
        return view('admin.translations.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'game_name' => 'required|string|max:255',
            'translation_name' => 'required|string|max:255',
            'translator' => 'required|string|max:255',
            'type' => 'required|in:free,popular,exclusive',
            'version' => 'required|string|max:50',
            'description' => 'nullable|string',
            'installation_instructions' => 'nullable|string',
            'image' => 'nullable|image|max:2048',
            'mediafire_url' => 'nullable|url',
            'category' => 'nullable|string',
            'completion_percentage' => 'nullable|integer|min:0|max:100',
        ]);

        if ($request->hasFile('image')) {
            $data['image'] = $request->file('image')->store('translations/images', 'public');
        }

        if (in_array($request->type, ['popular', 'exclusive']) && $request->hasFile('file')) {
            $data['file_path'] = $this->storageService->storePrivateFile($request->file('file'));
        }

        $data['last_updated'] = now();
        $data['release_date'] = now();

        Translation::create($data);

        return redirect()->route('admin.translations.index')->with('success', 'تم إنشاء التعريب بنجاح');
    }

    public function edit($id)
    {
        $translation = Translation::findOrFail($id);
        return view('admin.translations.edit', compact('translation'));
    }

    public function update(Request $request, $id)
    {
        $translation = Translation::findOrFail($id);
        $data = $request->validate([
            'game_name' => 'required|string|max:255',
            'translation_name' => 'required|string|max:255',
            'translator' => 'required|string|max:255',
            'type' => 'required|in:free,popular,exclusive',
            'version' => 'required|string|max:50',
            'description' => 'nullable|string',
            'installation_instructions' => 'nullable|string',
            'image' => 'nullable|image|max:2048',
            'mediafire_url' => 'nullable|url',
            'category' => 'nullable|string',
            'completion_percentage' => 'nullable|integer|min:0|max:100',
        ]);

        if ($request->hasFile('image')) {
            if ($translation->image) Storage::disk('public')->delete($translation->image);
            $data['image'] = $request->file('image')->store('translations/images', 'public');
        }

        if (in_array($request->type, ['popular', 'exclusive'])) {
            if ($request->hasFile('file')) {
                if ($translation->file_path) $this->storageService->deletePrivateFile($translation->file_path);
                $data['file_path'] = $this->storageService->storePrivateFile($request->file('file'));
            }
            $data['mediafire_url'] = null;
        } else {
            $data['mediafire_url'] = $request->mediafire_url;
            if ($translation->file_path) {
                $this->storageService->deletePrivateFile($translation->file_path);
                $data['file_path'] = null;
            }
        }

        $data['last_updated'] = now();
        $translation->update($data);

        return redirect()->route('admin.translations.index')->with('success', 'تم تحديث التعريب بنجاح');
    }

    public function destroy($id)
    {
        $translation = Translation::findOrFail($id);
        if ($translation->image) Storage::disk('public')->delete($translation->image);
        if ($translation->file_path) $this->storageService->deletePrivateFile($translation->file_path);
        $translation->delete();

        return redirect()->route('admin.translations.index')->with('success', 'تم حذف التعريب');
    }
}