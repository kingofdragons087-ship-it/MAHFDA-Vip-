<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Translation;
use App\Models\Subscription;
use App\Models\Download;

class DashboardController extends Controller
{
    public function index()
    {
        $totalUsers = User::count();
        $totalTranslations = Translation::count();
        $activeSubscriptions = Subscription::where('status', 'ACTIVE')->count();
        $totalDownloads = Download::count();
        $latestTranslations = Translation::latest()->take(5)->get();
        $latestUsers = User::latest()->take(5)->get();

        return view('admin.dashboard', compact(
            'totalUsers', 'totalTranslations', 'activeSubscriptions', 'totalDownloads',
            'latestTranslations', 'latestUsers'
        ));
    }
}