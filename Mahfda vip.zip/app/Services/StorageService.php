<?php

namespace App\Services;

use Illuminate\Support\Facades\Storage;
use Illuminate\Http\UploadedFile;

class StorageService
{
    public function storePrivateFile(UploadedFile $file, $folder = 'translations') {
        return $file->store("private/{$folder}", 'local');
    }

    public function getPrivateFile($path) {
        return Storage::disk('local')->exists($path) ? Storage::disk('local')->get($path) : null;
    }

    public function deletePrivateFile($path) {
        return Storage::disk('local')->exists($path) ? Storage::disk('local')->delete($path) : false;
    }
}