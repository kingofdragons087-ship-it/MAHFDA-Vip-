<?php

namespace App\Services;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Models\PayPalWebhook;

class PayPalWebhookService
{
    protected $subscriptionService;

    public function __construct(SubscriptionService $subscriptionService)
    {
        $this->subscriptionService = $subscriptionService;
    }

    public function handleWebhook(Request $request)
    {
        $payload = $request->all();
        $eventType = $payload['event_type'] ?? '';
        $subscriptionId = $payload['resource']['id'] ?? '';

        PayPalWebhook::create([
            'event_type' => $eventType,
            'subscription_id' => $subscriptionId,
            'payload' => json_encode($payload),
            'processed' => false,
        ]);

        switch ($eventType) {
            case 'BILLING.SUBSCRIPTION.CREATED':
            case 'BILLING.SUBSCRIPTION.ACTIVATED':
                $this->handleSubscriptionActivated($payload);
                break;
            case 'BILLING.SUBSCRIPTION.CANCELLED':
                $this->handleSubscriptionCancelled($payload);
                break;
            case 'BILLING.SUBSCRIPTION.EXPIRED':
            case 'BILLING.SUBSCRIPTION.SUSPENDED':
                $this->handleSubscriptionExpired($payload);
                break;
        }
        return true;
    }

    protected function handleSubscriptionActivated($payload) {
        $subscriptionId = $payload['resource']['id'];
        $planId = $payload['resource']['plan_id'];
        $userId = $payload['resource']['custom_id'] ?? null;
        if (!$userId) return;

        $plan = ($planId === env('PAYPAL_POPULAR_PLAN_ID')) ? 'popular' : 
                (($planId === env('PAYPAL_PREMIUM_PLAN_ID')) ? 'premium' : null);
        if ($plan) {
            $this->subscriptionService->activateSubscription($userId, $plan, $subscriptionId);
        }
    }

    protected function handleSubscriptionCancelled($payload) {
        $this->subscriptionService->cancelSubscription($payload['resource']['id']);
    }

    protected function handleSubscriptionExpired($payload) {
        $this->subscriptionService->expireSubscription($payload['resource']['id']);
    }
}