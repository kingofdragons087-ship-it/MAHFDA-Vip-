<?php

namespace App\Services;

use App\Models\User;
use App\Models\Subscription;
use Carbon\Carbon;

class SubscriptionService
{
    public function activateSubscription($userId, $plan, $paypalSubscriptionId)
    {
        $user = User::findOrFail($userId);
        $user->subscription_plan = $plan;
        $user->save();

        return Subscription::create([
            'user_id' => $userId,
            'plan' => $plan,
            'paypal_subscription_id' => $paypalSubscriptionId,
            'status' => 'ACTIVE',
            'started_at' => Carbon::now(),
            'next_billing_at' => Carbon::now()->addMonth(),
            'expires_at' => Carbon::now()->addMonth(),
        ]);
    }

    public function cancelSubscription($paypalSubscriptionId)
    {
        $subscription = Subscription::where('paypal_subscription_id', $paypalSubscriptionId)->first();
        if ($subscription) {
            $subscription->status = 'CANCELLED';
            $subscription->cancelled_at = Carbon::now();
            $subscription->save();

            $user = $subscription->user;
            $user->subscription_plan = 'free';
            $user->save();
            return true;
        }
        return false;
    }

    public function expireSubscription($paypalSubscriptionId)
    {
        $subscription = Subscription::where('paypal_subscription_id', $paypalSubscriptionId)->first();
        if ($subscription) {
            $subscription->status = 'EXPIRED';
            $subscription->save();

            $user = $subscription->user;
            $user->subscription_plan = 'free';
            $user->save();
            return true;
        }
        return false;
    }
}