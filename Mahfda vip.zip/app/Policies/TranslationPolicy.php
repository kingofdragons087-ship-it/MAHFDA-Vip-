<?php

namespace App\Policies;

use App\Models\User;
use App\Models\Translation;

class TranslationPolicy
{
    public function download(User $user, Translation $translation) {
        return $user->canDownload($translation);
    }
}