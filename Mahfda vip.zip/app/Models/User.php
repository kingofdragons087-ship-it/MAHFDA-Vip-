<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $fillable = [
        'google_id', 'name', 'email', 'avatar', 'role', 'subscription_plan',
    ];

    public function isAdmin() {
        return $this->role === 'admin';
    }

    public function activeSubscription() {
        return $this->subscriptions()->where('status', 'ACTIVE')->latest()->first();
    }

    public function canDownload($translation) {
        if ($translation->type === 'free') return true;
        if ($translation->type === 'popular') return in_array($this->subscription_plan, ['popular', 'premium']);
        if ($translation->type === 'exclusive') return $this->subscription_plan === 'premium';
        return false;
    }
    
    public function subscriptions() {
        return $this->hasMany(Subscription::class);
    }
}