<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Subscription extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id', 'plan', 'paypal_subscription_id', 'status',
        'started_at', 'next_billing_at', 'cancelled_at', 'expires_at'
    ];

    protected $casts = [
        'started_at' => 'datetime', 'next_billing_at' => 'datetime',
        'cancelled_at' => 'datetime', 'expires_at' => 'datetime',
    ];

    public function user() { return $this->belongsTo(User::class); }
}