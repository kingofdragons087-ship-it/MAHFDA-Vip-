<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Download extends Model
{
    use HasFactory;

    protected $fillable = ['user_id', 'translation_id', 'ip_address', 'downloaded_at'];
    
    protected $casts = ['downloaded_at' => 'datetime'];
}