<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Translation extends Model
{
    use HasFactory;

    protected $fillable = [
        'game_name', 'translation_name', 'translator', 'type', 'version', 
        'description', 'installation_instructions', 'image', 'mediafire_url', 
        'file_path', 'downloads', 'is_published', 'category', 
        'completion_percentage', 'release_date', 'last_updated'
    ];

    protected $casts = [
        'release_date' => 'datetime',
        'last_updated' => 'datetime',
        'is_published' => 'boolean',
    ];

    public function getTypeLabelAttribute() {
        return ['free' => '🆓 مجانية', 'popular' => '⭐ شائعة VIP', 'exclusive' => '👑 حصرية VIP'][$this->type] ?? 'غير معروف';
    }
}